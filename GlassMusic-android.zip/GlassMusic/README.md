# Glass Music (v0.1)

WebView wrapper around the prototype UI. Look, animations and mixing engine are identical to the web prototype.

## Get the APK
A. GitHub (nothing to install): create a repo, upload everything in this folder, open the Actions tab,
run "Build APK", download the GlassMusic-apk artifact (it contains app-debug.apk), copy it to the phone and install it.

B. Android Studio: File > Open this folder, wait for the Gradle sync, Build > Build APK(s).
Output: app/build/outputs/apk/debug/app-debug.apk

The page is app/src/main/assets/index.html.
